
# Question:1  Explain dimension reduction in machine learning.

## Dimensional Reduction : 
Dimensional reduction is a feature selection technique using which we reduce the number of features to be used for making a model without losing a significant amount of information compared to the original dataset. In other words, a dimensionality reduction technique projects a data of higher dimension to a lower-dimensional subspace.



## When to use Dimensionality Reduction?
Dimensionality reduction shall be used before feeding the data to a machine learning algorithm to achieve the following:
1. It reduces the size of the space in which the distances are calculated, thereby improving machine learning algorithm performance. 
2. It reduces the degrees of freedom for our dataset avoiding chances of overfitting.
3. Reducing the dimensionality using dimensionality reduction techniques can simplify the dataset facilitating a better description, visualisation, and insight.

### There are various methods used for dimensionality reduction include:
a. Principal Component Analysis (PCA)
b. Linear Discriminant Analysis (LDA)
c. Generalized Discriminant Analysis (GDA)

### Let's take an example of PCA

# Principal Component Analysis:
The principal component analysis is an unsupervised machine learning algorithm used for feature selection using dimensionality reduction techniques. As the name suggests, it finds out the principal components from the data. PCA transforms and fits the data from a higher-dimensional space to a new, lower-dimensional subspace This results into an entirely new coordinate system of the points where the first axis corresponds to the first principal component that explains the most variance in the data.

<img src="PCA_intro1.PNG" width="600">

## let's see how it helps to reduce the dimensions

### Importing Libraries


```
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```
from sklearn.datasets import load_breast_cancer
```


```
data = load_breast_cancer()#Load the data
```


```
df = pd.DataFrame(data['data'],columns=data['feature_names'])
df.head()  #it will return first n rows
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>mean radius</th>
      <th>mean texture</th>
      <th>mean perimeter</th>
      <th>mean area</th>
      <th>mean smoothness</th>
      <th>mean compactness</th>
      <th>mean concavity</th>
      <th>mean concave points</th>
      <th>mean symmetry</th>
      <th>mean fractal dimension</th>
      <th>...</th>
      <th>worst radius</th>
      <th>worst texture</th>
      <th>worst perimeter</th>
      <th>worst area</th>
      <th>worst smoothness</th>
      <th>worst compactness</th>
      <th>worst concavity</th>
      <th>worst concave points</th>
      <th>worst symmetry</th>
      <th>worst fractal dimension</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>17.99</td>
      <td>10.38</td>
      <td>122.80</td>
      <td>1001.0</td>
      <td>0.11840</td>
      <td>0.27760</td>
      <td>0.3001</td>
      <td>0.14710</td>
      <td>0.2419</td>
      <td>0.07871</td>
      <td>...</td>
      <td>25.38</td>
      <td>17.33</td>
      <td>184.60</td>
      <td>2019.0</td>
      <td>0.1622</td>
      <td>0.6656</td>
      <td>0.7119</td>
      <td>0.2654</td>
      <td>0.4601</td>
      <td>0.11890</td>
    </tr>
    <tr>
      <th>1</th>
      <td>20.57</td>
      <td>17.77</td>
      <td>132.90</td>
      <td>1326.0</td>
      <td>0.08474</td>
      <td>0.07864</td>
      <td>0.0869</td>
      <td>0.07017</td>
      <td>0.1812</td>
      <td>0.05667</td>
      <td>...</td>
      <td>24.99</td>
      <td>23.41</td>
      <td>158.80</td>
      <td>1956.0</td>
      <td>0.1238</td>
      <td>0.1866</td>
      <td>0.2416</td>
      <td>0.1860</td>
      <td>0.2750</td>
      <td>0.08902</td>
    </tr>
    <tr>
      <th>2</th>
      <td>19.69</td>
      <td>21.25</td>
      <td>130.00</td>
      <td>1203.0</td>
      <td>0.10960</td>
      <td>0.15990</td>
      <td>0.1974</td>
      <td>0.12790</td>
      <td>0.2069</td>
      <td>0.05999</td>
      <td>...</td>
      <td>23.57</td>
      <td>25.53</td>
      <td>152.50</td>
      <td>1709.0</td>
      <td>0.1444</td>
      <td>0.4245</td>
      <td>0.4504</td>
      <td>0.2430</td>
      <td>0.3613</td>
      <td>0.08758</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.42</td>
      <td>20.38</td>
      <td>77.58</td>
      <td>386.1</td>
      <td>0.14250</td>
      <td>0.28390</td>
      <td>0.2414</td>
      <td>0.10520</td>
      <td>0.2597</td>
      <td>0.09744</td>
      <td>...</td>
      <td>14.91</td>
      <td>26.50</td>
      <td>98.87</td>
      <td>567.7</td>
      <td>0.2098</td>
      <td>0.8663</td>
      <td>0.6869</td>
      <td>0.2575</td>
      <td>0.6638</td>
      <td>0.17300</td>
    </tr>
    <tr>
      <th>4</th>
      <td>20.29</td>
      <td>14.34</td>
      <td>135.10</td>
      <td>1297.0</td>
      <td>0.10030</td>
      <td>0.13280</td>
      <td>0.1980</td>
      <td>0.10430</td>
      <td>0.1809</td>
      <td>0.05883</td>
      <td>...</td>
      <td>22.54</td>
      <td>16.67</td>
      <td>152.20</td>
      <td>1575.0</td>
      <td>0.1374</td>
      <td>0.2050</td>
      <td>0.4000</td>
      <td>0.1625</td>
      <td>0.2364</td>
      <td>0.07678</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 30 columns</p>
</div>




```
df.shape
```




    (569, 30)




```
df.size # returns size of dataframe
```




    17070



### Observation:
As we can see we have 30 columns that means there are 30 features sometimes it is difficult to process but with the help of PCA technique we can reduce the dimension.
Let's see how


```
from sklearn.preprocessing import StandardScaler
stdsc = StandardScaler()
stdsc.fit(df)
```




    StandardScaler()




```
newdata = stdsc.transform(df)
```


```
from sklearn.decomposition import PCA
pca = PCA(n_components=4)
pca.fit(newdata)
```




    PCA(n_components=4)




```
a= pca.transform(newdata)
```


```
newdata.shape #before dimension reduction
```




    (569, 30)




```
a.shape #after dimension reduction
```




    (569, 4)



### Now we can see after dimension reduction only 4 features are left there.


```
plt.figure(figsize=(8,6))
plt.scatter(a[:,0],a[:,1],c=data['target'],cmap='winter')
plt.title("Principal Component Analysis")
plt.xlabel('PCA1')
plt.ylabel('PCA2')
```




    Text(0, 0.5, 'PCA2')




![png](output_23_1.png)


### Now you can apply machine learning algorithm,train the model and check the accuracy of the model.

## Question:2 How can you handle duplicate values in a dataset for a variable in Python using pandas?

### We have already imported Pandas library so let's start with reading the data


```
df=pd.read_csv("info.csv")#read the data
```


```
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Name</th>
      <th>Class</th>
      <th>Age</th>
      <th>Sex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>123</td>
      <td>Amu</td>
      <td>10th</td>
      <td>18</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>1</th>
      <td>456</td>
      <td>Kavi</td>
      <td>12th</td>
      <td>20</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>2</th>
      <td>444</td>
      <td>Kaula</td>
      <td>9th</td>
      <td>16</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>3</th>
      <td>233</td>
      <td>Bob</td>
      <td>8th</td>
      <td>14</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>4</th>
      <td>876</td>
      <td>Grove</td>
      <td>7th</td>
      <td>12</td>
      <td>Male</td>
    </tr>
  </tbody>
</table>
</div>




```
df.shape # returns number of rows and number of columns of the dataframe.

```




    (13, 5)




```
df.size # returns size of dataframe
```




    65



#### There are two methods that will help to identify and remove the duplicate data: 
 1. duplicated (To identify duplicated data)
 2. drop_duplicates (To remove duplicate data)
 
 
 Each takes as an argument the columns to use to identify duplicated rows.


```
df.duplicated() #to check how many dulicates are present there
```




    0     False
    1     False
    2     False
    3     False
    4     False
    5     False
    6     False
    7      True
    8     False
    9     False
    10     True
    11    False
    12     True
    dtype: bool



### Obeservation : 
    True value shows duplicate data. So as we can see we have 3 duplicate data so we can easily remove it through   
    drop_duplicates method


```
df.drop_duplicates(["Name","ID","Class","Age","Sex"],inplace=True) #remove duplicate data
```


```
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>Name</th>
      <th>Class</th>
      <th>Age</th>
      <th>Sex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>123</td>
      <td>Amu</td>
      <td>10th</td>
      <td>18</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>1</th>
      <td>456</td>
      <td>Kavi</td>
      <td>12th</td>
      <td>20</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>2</th>
      <td>444</td>
      <td>Kaula</td>
      <td>9th</td>
      <td>16</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>3</th>
      <td>233</td>
      <td>Bob</td>
      <td>8th</td>
      <td>14</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>4</th>
      <td>876</td>
      <td>Grove</td>
      <td>7th</td>
      <td>12</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>5</th>
      <td>444</td>
      <td>Apya</td>
      <td>6th</td>
      <td>10</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>6</th>
      <td>98</td>
      <td>Saumi</td>
      <td>3rd</td>
      <td>6</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>8</th>
      <td>444</td>
      <td>Kaula</td>
      <td>9th</td>
      <td>4</td>
      <td>Female</td>
    </tr>
    <tr>
      <th>9</th>
      <td>836</td>
      <td>Soro</td>
      <td>1st</td>
      <td>3</td>
      <td>Male</td>
    </tr>
    <tr>
      <th>11</th>
      <td>309</td>
      <td>Elish</td>
      <td>2nd</td>
      <td>5</td>
      <td>Female</td>
    </tr>
  </tbody>
</table>
</div>




```
df.duplicated() #check again
```




    0     False
    1     False
    2     False
    3     False
    4     False
    5     False
    6     False
    8     False
    9     False
    11    False
    dtype: bool




```
df.shape
```




    (10, 5)



### So finally we can see there is no duplicate data

<img src="img.PNG" width="500">
